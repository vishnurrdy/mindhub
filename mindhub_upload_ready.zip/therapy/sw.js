const CACHE = "therapy-cache-v1";
const FILES = [
  "/",
  "/therapy/index.html",
  "/therapy/styles.css",
  "/therapy/app.js",
];
self.addEventListener("install", (e) => {
  e.waitUntil(
    caches
      .open(CACHE)
      .then((c) => c.addAll(FILES))
      .catch(() => {})
  );
  self.skipWaiting();
});
self.addEventListener("activate", (e) => {
  e.waitUntil(self.clients.claim());
});
self.addEventListener("fetch", (e) => {
  const req = e.request;
  e.respondWith(
    caches
      .match(req)
      .then(
        (r) => r || fetch(req).catch(() => caches.match("/therapy/index.html"))
      )
  );
});
