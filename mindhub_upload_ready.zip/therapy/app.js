// Simple IndexedDB wrapper for storing media blobs and metadata
const DB_NAME = "therapy-db";
const STORE = "media";

function openDB() {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
      }
    };
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

async function addMediaEntry({ title, type, blob, origName }) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    const store = tx.objectStore(STORE);
    const item = {
      title: title || origName || "media-" + Date.now(),
      type,
      blob,
      origName,
      created: Date.now(),
    };
    const r = store.add(item);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}

async function getAll() {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readonly");
    const store = tx.objectStore(STORE);
    const req = store.getAll();
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

async function deleteItem(id) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    const store = tx.objectStore(STORE);
    const r = store.delete(id);
    r.onsuccess = () => res(true);
    r.onerror = () => rej(r.error);
  });
}

// UI wiring
const fileInput = document.getElementById("fileInput");
const addBtn = document.getElementById("addBtn");
const itemsEl = document.getElementById("items");
const titleInput = document.getElementById("titleInput");
const typeSelect = document.getElementById("typeSelect");
const videoPlayer = document.getElementById("videoPlayer");
const audioPlayer = document.getElementById("audioPlayer");
const exportListBtn = document.getElementById("exportList");
const importJson = document.getElementById("importJson");

addBtn.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  let suggestedType = "audio";
  if (f.type && f.type.startsWith("video")) suggestedType = "video";
  const chosen = typeSelect.value === "auto" ? suggestedType : typeSelect.value;
  const title = titleInput.value.trim() || f.name;
  const blob = f.slice(0, f.size, f.type);
  await addMediaEntry({ title, type: chosen, blob, origName: f.name });
  titleInput.value = "";
  fileInput.value = "";
  await render();
});

async function render() {
  const all = await getAll();
  itemsEl.innerHTML = "";
  if (!all.length)
    itemsEl.innerHTML =
      '<div class="muted">No media added yet. Click "Add Media" to import audio/video files from this device.</div>';
  all.forEach((it) => {
    const el = document.createElement("div");
    el.className = "item";
    const meta = document.createElement("div");
    meta.className = "meta";
    const h = document.createElement("h4");
    h.textContent = it.title;
    const p = document.createElement("p");
    p.textContent = `${it.type} • ${new Date(it.created).toLocaleString()} • ${
      it.origName || ""
    }`;
    meta.appendChild(h);
    meta.appendChild(p);
    const actions = document.createElement("div");
    const play = document.createElement("button");
    play.textContent = "Play";
    play.addEventListener("click", () => playItem(it));
    const download = document.createElement("button");
    download.textContent = "Download";
    download.addEventListener("click", () => downloadItem(it));
    const del = document.createElement("button");
    del.textContent = "Delete";
    del.style.color = "crimson";
    del.addEventListener("click", async () => {
      if (confirm("Delete this item?")) {
        await deleteItem(it.id);
        await render();
      }
    });
    actions.appendChild(play);
    actions.appendChild(download);
    actions.appendChild(del);
    el.appendChild(meta);
    el.appendChild(actions);
    itemsEl.appendChild(el);
  });
}

function playItem(it) {
  const url = URL.createObjectURL(it.blob);
  if (it.type === "video") {
    audioPlayer.style.display = "none";
    audioPlayer.pause();
    videoPlayer.style.display = "block";
    videoPlayer.src = url;
    videoPlayer.play();
  } else {
    videoPlayer.style.display = "none";
    videoPlayer.pause();
    audioPlayer.style.display = "block";
    audioPlayer.src = url;
    audioPlayer.play();
  }
}

function downloadItem(it) {
  const url = URL.createObjectURL(it.blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = it.origName || it.title || "media";
  a.click();
  URL.revokeObjectURL(url);
}

exportListBtn.addEventListener("click", async () => {
  const all = await getAll();
  const metadata = all.map((a) => ({
    id: a.id,
    title: a.title,
    type: a.type,
    origName: a.origName,
    created: a.created,
  }));
  const blob = new Blob([JSON.stringify(metadata, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "therapy_metadata.json";
  a.click();
  URL.revokeObjectURL(url);
});

importJson.addEventListener("change", async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  try {
    const txt = await f.text();
    const arr = JSON.parse(txt);
    // Import only metadata: add placeholders (user must re-add blobs manually)
    if (Array.isArray(arr)) {
      alert(
        "Imported metadata. Note: blobs are not included. Re-add source files to make items playable."
      );
    }
  } catch (e) {
    alert("Import failed");
  }
});

// initial render
render();
