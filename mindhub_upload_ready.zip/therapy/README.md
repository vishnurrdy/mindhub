Therapy Hub (Offline)

This small offline web app lets you add audio and video files from your device, store them locally in the browser (IndexedDB), and play them back offline.

How it works

- Files are stored as Blobs in IndexedDB (object store `media`) so they persist across page loads.
- A simple Service Worker caches the app shell for offline loading.
- You can Export the metadata as JSON. The export does NOT include the blobs.

Usage

1. Open `therapy/index.html` in a modern browser (Chrome, Edge, Firefox, Safari).
2. Click "Add Media" and select an audio or video file from your device. Enter an optional title and choose type (or keep Auto detect).
3. The item appears in your Library. Click "Play" to play it.
4. Use "Download" to download the stored file, or "Delete" to remove it.

Notes & limitations

- This is a client-side demo. For large libraries or secure sharing you'd use a backend and proper file storage.
- Blobs are stored in IndexedDB; depending on browser settings there may be quota limits.
- If you clear browser data, stored files will be removed.

If you want, I can:

- Add thumbnail extraction for videos.
- Add tags and categories, search, and simple playlists.
- Add an improved UI and modal dialogs instead of native prompts.
