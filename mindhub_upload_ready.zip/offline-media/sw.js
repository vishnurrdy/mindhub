const CACHE = "offline-media-v1";
// Use relative paths so the service worker can be installed when the app is
// served from a subpath during development.
const FILES = ["./", "./index.html", "./styles.css", "./app.js"];
self.addEventListener("install", (e) => {
  e.waitUntil(
    caches
      .open(CACHE)
      .then((c) => c.addAll(FILES))
      .catch(() => {})
  );
  self.skipWaiting();
});
self.addEventListener("activate", (e) => {
  e.waitUntil(self.clients.claim());
});
self.addEventListener("fetch", (e) => {
  // Only handle navigation requests and same-origin requests to avoid
  // interfering with third-party resources.
  const req = e.request;
  if (req.method !== "GET") return;
  e.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).catch(() => caches.match("./index.html"));
    })
  );
});
