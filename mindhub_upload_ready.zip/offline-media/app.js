// Offline Media mini-app: IndexedDB with media + playlists
const DB = "offline-media-db";
const STORE_MEDIA = "media";
const STORE_PL = "playlists";

function openDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => {
      const db = r.result;
      if (!db.objectStoreNames.contains(STORE_MEDIA))
        db.createObjectStore(STORE_MEDIA, {
          keyPath: "id",
          autoIncrement: true,
        });
      if (!db.objectStoreNames.contains(STORE_PL))
        db.createObjectStore(STORE_PL, { keyPath: "id", autoIncrement: true });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}

async function addMedia({ title, type, blob, orig }) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE_MEDIA, "readwrite");
    const store = tx.objectStore(STORE_MEDIA);
    const item = { title, type, blob, origName: orig, created: Date.now() };
    const rq = store.add(item);
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
async function getAllMedia() {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE_MEDIA, "readonly");
    const store = tx.objectStore(STORE_MEDIA);
    const rq = store.getAll();
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}

// Playlists (store id refs): { id, name, items: [mediaId] }
async function deleteMedia(id) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE_MEDIA, "readwrite");
    const store = tx.objectStore(STORE_MEDIA);
    const rq = store.delete(id);
    rq.onsuccess = () => res(true);
    rq.onerror = () => rej(rq.error);
  });
}

async function createPlaylist(name) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE_PL, "readwrite");
    const store = tx.objectStore(STORE_PL);
    const rq = store.add({ name, items: [], created: Date.now() });
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}

async function getPlaylists() {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE_PL, "readonly");
    const store = tx.objectStore(STORE_PL);
    const rq = store.getAll();
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}

// UI wiring (guard in case file opened outside browser or DOM missing)
const fileInput =
  document.getElementById && document.getElementById("fileInput");
const addBtn = document.getElementById && document.getElementById("addBtn");
const demoBtn = document.getElementById && document.getElementById("demoBtn");
const itemsEl = document.getElementById && document.getElementById("items");
const titleInput =
  document.getElementById && document.getElementById("titleInput");
const typeSelect =
  document.getElementById && document.getElementById("typeSelect");
const videoPlayer =
  document.getElementById && document.getElementById("videoPlayer");
const audioPlayer =
  document.getElementById && document.getElementById("audioPlayer");
const exportMeta =
  document.getElementById && document.getElementById("exportMeta");
const importMeta =
  document.getElementById && document.getElementById("importMeta");
const search = document.getElementById && document.getElementById("search");
const plName = document.getElementById && document.getElementById("plName");
const createPl = document.getElementById && document.getElementById("createPl");
const plSelect = document.getElementById && document.getElementById("plSelect");

addBtn.addEventListener("click", () => fileInput.click());
demoBtn &&
  demoBtn.addEventListener("click", async () => {
    demoBtn.disabled = true;
    demoBtn.textContent = "Adding...";
    try {
      const a = await makeDemoAudio();
      const v = await makeDemoVideo();
      await addMedia({
        title: "Demo Audio (sine)",
        type: "audio",
        blob: a,
        orig: "demo-audio.wav",
      });
      await addMedia({
        title: "Demo Video (canvas)",
        type: "video",
        blob: v,
        orig: "demo-video.webm",
      });
      await render();
      alert("Demo media added");
    } catch (e) {
      console.warn(e);
      alert("Failed to add demo media");
    }
    demoBtn.disabled = false;
    demoBtn.textContent = "Populate demo media";
  });
fileInput.addEventListener("change", async (e) => {
  const files = Array.from(e.target.files || []);
  if (!files.length) return;
  const titles = (titleInput.value || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    let guessed = "audio";
    if (f.type && f.type.startsWith("video")) guessed = "video";
    const chosen = typeSelect.value === "auto" ? guessed : typeSelect.value;
    const title = titles[i] || titles[0] || f.name;
    await addMedia({
      title,
      type: chosen,
      blob: f.slice(0, f.size, f.type),
      orig: f.name,
    });
  }
  titleInput.value = "";
  fileInput.value = "";
  await render();
});

async function render() {
  const all = await getAllMedia();
  const q = (search.value || "").toLowerCase();
  itemsEl.innerHTML = "";
  const filtered = all.filter(
    (it) =>
      !q ||
      it.title.toLowerCase().includes(q) ||
      (it.origName || "").toLowerCase().includes(q)
  );
  if (!filtered.length)
    itemsEl.innerHTML = '<div class="muted">No media found</div>';
  filtered.forEach((it) => {
    const el = document.createElement("div");
    el.className = "item";
    const meta = document.createElement("div");
    meta.className = "meta";
    const h = document.createElement("h4");
    h.textContent = it.title;
    const p = document.createElement("p");
    p.textContent = `${it.type} • ${new Date(it.created).toLocaleString()} • ${
      it.origName || ""
    }`;
    meta.appendChild(h);
    meta.appendChild(p);
    const actions = document.createElement("div");
    const play = document.createElement("button");
    play.textContent = "Play";
    play.addEventListener("click", () => playItem(it));
    const dl = document.createElement("button");
    dl.textContent = "Download";
    dl.addEventListener("click", () => downloadItem(it));
    const del = document.createElement("button");
    del.textContent = "Delete";
    del.style.color = "crimson";
    del.addEventListener("click", async () => {
      if (confirm("Delete?")) {
        await deleteMedia(it.id);
        await render();
      }
    });
    actions.appendChild(play);
    actions.appendChild(dl);
    actions.appendChild(del);
    el.appendChild(meta);
    el.appendChild(actions);
    itemsEl.appendChild(el);
  });
  await renderPlaylists();
}

function playItem(it) {
  const url = URL.createObjectURL(it.blob);
  if (it.type === "video") {
    audioPlayer.style.display = "none";
    audioPlayer.pause();
    videoPlayer.style.display = "block";
    videoPlayer.src = url;
    videoPlayer.play();
  } else {
    videoPlayer.style.display = "none";
    videoPlayer.pause();
    audioPlayer.style.display = "block";
    audioPlayer.src = url;
    audioPlayer.play();
  }
}
function downloadItem(it) {
  const url = URL.createObjectURL(it.blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = it.origName || it.title || "media";
  a.click();
  URL.revokeObjectURL(url);
}

exportMeta.addEventListener("click", async () => {
  const all = await getAllMedia();
  const meta = all.map((a) => ({
    id: a.id,
    title: a.title,
    type: a.type,
    origName: a.origName,
    created: a.created,
  }));
  const blob = new Blob([JSON.stringify(meta, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "offline_media_meta.json";
  a.click();
  URL.revokeObjectURL(url);
});
importMeta.addEventListener("change", async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  try {
    const txt = await f.text();
    const arr = JSON.parse(txt);
    alert("Imported metadata. Re-add blobs manually to make playable.");
  } catch (e) {
    alert("Import failed");
  }
});

createPl.addEventListener("click", async () => {
  const name = (plName.value || "").trim();
  if (!name) return alert("Enter playlist name");
  await createPlaylist(name);
  plName.value = "";
  await renderPlaylists();
});

async function renderPlaylists() {
  const pls = await getPlaylists();
  plSelect.innerHTML = "";
  const optAll = document.createElement("option");
  optAll.value = "all";
  optAll.textContent = "All items";
  plSelect.appendChild(optAll);
  pls.forEach((p) => {
    const o = document.createElement("option");
    o.value = p.id;
    o.textContent = p.name;
    plSelect.appendChild(o);
  });
}

// initial
render();

// Demo generators ---------------------------------------------------------
async function makeDemoAudio() {
  // Generate ~1s sine WAV PCM16 mono
  const sampleRate = 16000;
  const dur = 1.2;
  const freq = 440;
  const len = Math.floor(sampleRate * dur);
  const buf = new ArrayBuffer(44 + len * 2);
  const vw = new DataView(buf);
  // WAV header
  function writeString(offset, s) {
    for (let i = 0; i < s.length; i++) vw.setUint8(offset + i, s.charCodeAt(i));
  }
  writeString(0, "RIFF");
  vw.setUint32(4, 36 + len * 2, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  vw.setUint32(16, 16, true);
  vw.setUint16(20, 1, true);
  vw.setUint16(22, 1, true);
  vw.setUint32(24, sampleRate, true);
  vw.setUint32(28, sampleRate * 2, true);
  vw.setUint16(32, 2, true);
  vw.setUint16(34, 16, true);
  writeString(36, "data");
  vw.setUint32(40, len * 2, true);
  // samples
  for (let i = 0; i < len; i++) {
    const t = i / sampleRate;
    const s = Math.sin(2 * Math.PI * freq * t) * Math.exp(-2 * t);
    const s16 = Math.max(-1, Math.min(1, s)) * 0x7fff;
    vw.setInt16(44 + i * 2, s16, true);
  }
  return new Blob([buf], { type: "audio/wav" });
}

async function makeDemoVideo() {
  // small 320x180 canvas recording for ~2s
  const canvas = Object.assign(document.createElement("canvas"), {
    width: 320,
    height: 180,
  });
  const ctx = canvas.getContext("2d");
  let frames = [];
  // draw frames
  const total = 40;
  for (let i = 0; i < total; i++) {
    ctx.fillStyle = "#0ea5a4";
    ctx.fillRect(0, 0, 320, 180);
    ctx.fillStyle = "white";
    ctx.font = "24px sans-serif";
    ctx.fillText("Demo video " + (i + 1), 20, 90);
    ctx.fillRect(20, 120, (i / total) * 280, 12);
    frames.push(canvas.toDataURL("image/webp"));
  }
  // assemble as WebM via MediaRecorder if available
  if (window.MediaRecorder && canvas.captureStream) {
    const stream = canvas.captureStream(20);
    const chunks = [];
    const mr = new MediaRecorder(stream, { mimeType: "video/webm" });
    mr.ondataavailable = (e) => {
      if (e.data && e.data.size) chunks.push(e.data);
    };
    mr.start();
    for (let i = 0; i < total; i++) {
      // draw animation
      ctx.fillStyle = "#0ea5a4";
      ctx.fillRect(0, 0, 320, 180);
      ctx.fillStyle = "white";
      ctx.font = "24px sans-serif";
      ctx.fillText("Demo video " + (i + 1), 20, 90);
      ctx.fillRect(20, 120, (i / total) * 280, 12);
      await new Promise((r) => setTimeout(r, 50));
    }
    mr.stop();
    await new Promise((r) => (mr.onstop = r));
    return new Blob(chunks, { type: "video/webm" });
  }
  // fallback: create a tiny mp4-like placeholder as blob from first frame (not real video)
  const bin = atob(frames[0].split(",")[1]);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: "image/webp" });
}
