Offline Media Mini-App

Features:

- Store audio/video files locally in IndexedDB and play them offline
- Create simple playlists (metadata only)
- Export/import metadata JSON
- Service Worker caches the app shell for offline access

How to use:

1. Open `offline-media/index.html` in a modern browser.
2. Click "Add Media" and select audio/video files from your device.
3. Create playlists and play items offline.

Demo media:

- Use the "Populate demo media" button to add a short demo audio (sine wave) and a small demo video (canvas capture) to the library for testing.

Limitations:

- Metadata export does not include blobs. To backup blobs you'd need packaging or a backend.
- This is a client-side demo; for production integrate with a server and proper auth.

Next improvements:

- Add playlist editing (add/remove items)
- Add thumbnail generation, waveform preview, and smoother UI
- Add backup/restore including blobs (requires zipping or backend)
