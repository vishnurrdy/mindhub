Media Library

This folder contains a small offline media library that stores audio/video files in IndexedDB and lets you play them in the browser.

Quick start (serve locally):

# Using Python 3 (recommended, no install required on macOS)

python3 -m http.server 8000

# Using Node (if you have http-server installed)

npx http-server -p 8000

Then open http://localhost:8000/media-library/ or http://localhost:8000/offline-media/ in Chrome.

Why not open the file directly? Browsers restrict Service Worker registration and some secure APIs when the page is opened via file://. To get full offline caching and predictable behavior, run a local web server as shown above.

Notes:

- Service worker registration is intentionally skipped when the page is opened via file://; you'll see a small banner if that happens.
- Back up your files by exporting metadata; blobs are not included in metadata exports.
