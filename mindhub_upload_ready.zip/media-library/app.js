// media-library app: shares IndexedDB 'offline-media-db' with offline-media
const DB = "offline-media-db";
const STORE = "media";
function openDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => {
      const db = r.result;
      if (!db.objectStoreNames.contains(STORE))
        db.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function addMediaEntry(obj) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    const st = tx.objectStore(STORE);
    const rq = st.add(obj);
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
async function getAll() {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readonly");
    const st = tx.objectStore(STORE);
    const rq = st.getAll();
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
async function deleteItem(id) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => res(true);
    tx.onerror = () => rej(tx.error);
  });
}

const fileInput = document.getElementById("fileInput");
const uploadBtn = document.getElementById("uploadBtn");
const demoBtn = document.getElementById("demoBtn");
const backBtn = document.getElementById("backBtn");
const itemsEl = document.getElementById("items");
const videoPlayer = document.getElementById("videoPlayer");
const audioPlayer = document.getElementById("audioPlayer");
const dropZone = document.getElementById("dropZone");
const chooseBtn = document.getElementById("chooseBtn");
const selectedFilesEl = document.getElementById("selectedFiles");

let selectedFiles = [];

function renderSelected() {
  if (!selectedFiles.length) {
    selectedFilesEl.textContent = "No files selected";
    uploadBtn.disabled = true;
    return;
  }
  selectedFilesEl.innerHTML = "";
  selectedFiles.forEach((f, i) => {
    const d = document.createElement("div");
    d.textContent = `${f.name} (${Math.round(f.size / 1024)} KB)`;
    selectedFilesEl.appendChild(d);
  });
  uploadBtn.disabled = false;
}

chooseBtn && chooseBtn.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", (e) => {
  selectedFiles = Array.from(e.target.files || []);
  renderSelected();
});
if (dropZone) {
  ["dragenter", "dragover"].forEach((ev) =>
    dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropZone.style.background = "#ecfeff";
    })
  );
  ["dragleave", "drop"].forEach((ev) =>
    dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropZone.style.background = "white";
    })
  );
  dropZone.addEventListener("drop", (e) => {
    const files = Array.from(e.dataTransfer.files || []);
    selectedFiles = selectedFiles.concat(files);
    renderSelected();
  });
}

uploadBtn.addEventListener("click", async () => {
  const files = selectedFiles.length
    ? selectedFiles
    : Array.from(fileInput.files || []);
  if (!files.length) return alert("Select files");
  uploadBtn.disabled = true;
  try {
    for (const f of files) {
      // simple size check: warn if >50MB
      const max = 50 * 1024 * 1024;
      if (f.size > max) {
        if (
          !confirm(
            `${f.name} is ${
              Math.round((f.size / 1024 / 1024) * 10) / 10
            }MB — continue?`
          )
        )
          continue;
      }
      const type = f.type && f.type.startsWith("video") ? "video" : "audio";
      await addMediaEntry({
        title: f.name,
        type,
        blob: f,
        origName: f.name,
        created: Date.now(),
      });
    }
    selectedFiles = [];
    fileInput.value = "";
    renderSelected();
    render();
    alert("Uploaded");
  } catch (e) {
    console.warn(e);
    alert("Upload failed");
  }
  uploadBtn.disabled = false;
});

demoBtn.addEventListener("click", async () => {
  demoBtn.disabled = true;
  demoBtn.textContent = "Adding...";
  try {
    const a = await makeDemoAudio();
    const v = await makeDemoVideo();
    await addMediaEntry({
      title: "Demo Audio (sine)",
      type: "audio",
      blob: a,
      origName: "demo-audio.wav",
      created: Date.now(),
    });
    await addMediaEntry({
      title: "Demo Video (canvas)",
      type: "video",
      blob: v,
      origName: "demo-video.webm",
      created: Date.now(),
    });
    await render();
    alert("Demo added");
  } catch (e) {
    console.warn(e);
    alert("Demo failed");
  }
  demoBtn.disabled = false;
  demoBtn.textContent = "Populate demo media";
});

backBtn.addEventListener("click", () => {
  // If inside an iframe, ask parent to close modal
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: "mh_close_media_modal" }, "*");
      return;
    }
  } catch (e) {}
  location.href = "Dashboard.html";
});

async function render() {
  const all = await getAll().catch(() => []);
  itemsEl.innerHTML = "";
  if (!all.length) itemsEl.innerHTML = '<div class="muted">No media yet</div>';
  all.forEach((it) => {
    const el = document.createElement("div");
    el.className = "item";
    const m = document.createElement("div");
    const h = document.createElement("h4");
    h.textContent = it.title;
    const p = document.createElement("p");
    p.textContent = `${it.type} • ${new Date(it.created).toLocaleString()}`;
    p.style.margin = "0";
    p.style.fontSize = "13px";
    p.style.color = "#6b7280";
    m.appendChild(h);
    m.appendChild(p);
    const actions = document.createElement("div");
    const play = document.createElement("button");
    play.textContent = "Play";
    play.className = "secondary";
    play.style.marginRight = "8px";
    play.addEventListener("click", () => {
      const url = URL.createObjectURL(it.blob);
      if (it.type === "video") {
        audioPlayer.style.display = "none";
        audioPlayer.pause();
        videoPlayer.style.display = "block";
        videoPlayer.src = url;
        videoPlayer.play().catch(() => {});
      } else {
        videoPlayer.style.display = "none";
        videoPlayer.pause();
        audioPlayer.style.display = "block";
        audioPlayer.src = url;
        audioPlayer.play().catch(() => {});
      }
    });
    const dl = document.createElement("button");
    dl.textContent = "Download";
    dl.style.marginRight = "8px";
    dl.addEventListener("click", () => {
      const url = URL.createObjectURL(it.blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = it.origName || it.title || "media";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    const del = document.createElement("button");
    del.textContent = "Delete";
    del.style.background = "crimson";
    del.style.marginLeft = "8px";
    del.addEventListener("click", async () => {
      if (!confirm("Delete?")) return;
      await deleteItem(it.id);
      render();
    });
    actions.appendChild(play);
    actions.appendChild(dl);
    actions.appendChild(del);
    el.appendChild(m);
    el.appendChild(actions);
    itemsEl.appendChild(el);
  });
}

render();

// demo generators (copy from offline-media app)
async function makeDemoAudio() {
  const sampleRate = 16000;
  const dur = 1.2;
  const freq = 440;
  const len = Math.floor(sampleRate * dur);
  const buf = new ArrayBuffer(44 + len * 2);
  const vw = new DataView(buf);
  function writeString(offset, s) {
    for (let i = 0; i < s.length; i++) vw.setUint8(offset + i, s.charCodeAt(i));
  }
  writeString(0, "RIFF");
  vw.setUint32(4, 36 + len * 2, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  vw.setUint32(16, 16, true);
  vw.setUint16(20, 1, true);
  vw.setUint16(22, 1, true);
  vw.setUint32(24, sampleRate, true);
  vw.setUint32(28, sampleRate * 2, true);
  vw.setUint16(32, 2, true);
  vw.setUint16(34, 16, true);
  writeString(36, "data");
  vw.setUint32(40, len * 2, true);
  for (let i = 0; i < len; i++) {
    const t = i / sampleRate;
    const s = Math.sin(2 * Math.PI * freq * t) * Math.exp(-2 * t);
    const s16 = Math.max(-1, Math.min(1, s)) * 0x7fff;
    vw.setInt16(44 + i * 2, s16, true);
  }
  return new Blob([buf], { type: "audio/wav" });
}

async function makeDemoVideo() {
  const canvas = Object.assign(document.createElement("canvas"), {
    width: 320,
    height: 180,
  });
  const ctx = canvas.getContext("2d");
  const frames = [];
  const total = 40;
  for (let i = 0; i < total; i++) {
    ctx.fillStyle = "#0ea5a4";
    ctx.fillRect(0, 0, 320, 180);
    ctx.fillStyle = "white";
    ctx.font = "24px sans-serif";
    ctx.fillText("Demo video " + (i + 1), 20, 90);
    ctx.fillRect(20, 120, (i / total) * 280, 12);
    frames.push(canvas.toDataURL("image/webp"));
  }
  if (window.MediaRecorder && canvas.captureStream) {
    const stream = canvas.captureStream(20);
    const chunks = [];
    const mr = new MediaRecorder(stream, { mimeType: "video/webm" });
    mr.ondataavailable = (e) => {
      if (e.data && e.data.size) chunks.push(e.data);
    };
    mr.start();
    for (let i = 0; i < total; i++) {
      ctx.fillStyle = "#0ea5a4";
      ctx.fillRect(0, 0, 320, 180);
      ctx.fillStyle = "white";
      ctx.font = "24px sans-serif";
      ctx.fillText("Demo video " + (i + 1), 20, 90);
      ctx.fillRect(20, 120, (i / total) * 280, 12);
      await new Promise((r) => setTimeout(r, 50));
    }
    mr.stop();
    await new Promise((r) => (mr.onstop = r));
    return new Blob(chunks, { type: "video/webm" });
  }
  const bin = atob(frames[0].split(",")[1]);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: "image/webp" });
}
