(function () {
  const goalsKey = "wh_micro_goals_v1";
  const addBtn = document.getElementById("addGoal");
  const titleInput = document.getElementById("goalTitle");
  const list = document.getElementById("goalsList");

  function load() {
    try {
      return JSON.parse(localStorage.getItem(goalsKey) || "[]");
    } catch (e) {
      return [];
    }
  }
  function save(v) {
    try {
      localStorage.setItem(goalsKey, JSON.stringify(v));
    } catch (e) {}
  }

  function render() {
    const data = load();
    list.innerHTML = "";
    data.forEach((g, gi) => {
      const el = document.createElement("div");
      el.className = "p-3 border rounded";
      el.innerHTML = `
        <div class="flex items-start gap-3">
          <input type="checkbox" class="goal-complete mt-1" data-gi="${gi}" ${
        g.done ? "checked" : ""
      } />
          <div class="flex-grow">
            <div class="flex items-center gap-2">
              <strong class="goal-title">${escapeHtml(g.title)}</strong>
              <span class="text-xs text-gray-500">${
                g.deadline
                  ? " • due " + new Date(g.deadline).toLocaleString()
                  : ""
              }</span>
            </div>
            <div class="mt-2 space-y-2">
              <div class="flex gap-2">
                <input class="subtask-input flex-grow rounded border px-2 py-1" placeholder="Add micro-step (e.g. read 10 pages)" />
                <button class="add-subtask text-sm px-2 py-1 bg-gray-100 rounded">Add</button>
              </div>
              <ul class="subtasks list-disc ml-5 text-sm text-gray-700"></ul>
            </div>
          </div>
          <div class="flex flex-col gap-2">
            <button class="set-deadline text-xs px-2 py-1 bg-indigo-50 text-indigo-700 rounded">Set Deadline</button>
            <button class="remove-goal text-xs px-2 py-1 bg-red-50 text-red-700 rounded">Remove</button>
          </div>
        </div>
      `;
      list.appendChild(el);

      const subtasksEl = el.querySelector(".subtasks");
      (g.subtasks || []).forEach((s, si) => {
        const li = document.createElement("li");
        li.innerHTML = `<label class="flex items-center gap-2"><input type="checkbox" class="subtask-check" data-gi="${gi}" data-si="${si}" ${
          s.done ? "checked" : ""
        } /> <span class="ml-1">${escapeHtml(s.text)}</span></label>`;
        subtasksEl.appendChild(li);
      });

      // handlers
      el.querySelector(".add-subtask").addEventListener("click", () => {
        const v = el.querySelector(".subtask-input").value.trim();
        if (!v) return;
        g.subtasks = g.subtasks || [];
        g.subtasks.push({ text: v, done: false });
        saveAndRender();
      });
      el.querySelector(".remove-goal").addEventListener("click", () => {
        const d = load();
        d.splice(gi, 1);
        save(d);
        render();
      });
      el.querySelector(".set-deadline").addEventListener("click", () => {
        const d = prompt("Set deadline (YYYY-MM-DD HH:MM)");
        if (!d) return;
        const t = new Date(d);
        if (isNaN(t)) return alert("Invalid date");
        g.deadline = t.getTime();
        saveAndRender();
      });
      el.querySelector(".goal-complete").addEventListener("change", (ev) => {
        g.done = !!ev.target.checked;
        saveAndRender();
      });
      el.querySelectorAll(".subtask-check").forEach((c) => {
        c.addEventListener("change", (ev) => {
          const si = parseInt(c.getAttribute("data-si"), 10);
          g.subtasks[si].done = !!ev.target.checked;
          saveAndRender();
        });
      });
    });
  }

  function saveAndRender() {
    save(load());
    render();
  }

  addBtn.addEventListener("click", () => {
    const t = titleInput.value.trim();
    if (!t) return;
    const d = load();
    d.push({ title: t, subtasks: [], done: false });
    save(d);
    titleInput.value = "";
    render();
  });

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      }[c];
    });
  }

  // initial render
  render();
})();
