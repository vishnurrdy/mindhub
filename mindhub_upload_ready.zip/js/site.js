// Central site configuration helper
(function () {
  const DEFAULT_NAME = "Mind Hub"; // fallback default

  function normalizeName(n) {
    return String(n || "").trim();
  }

  function computeSlug(n) {
    return (
      String(n || DEFAULT_NAME)
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "")
        .slice(0, 32) || "site"
    );
  }

  function storedName() {
    try {
      const s = localStorage.getItem("wh_site_name");
      if (s) return normalizeName(s);
    } catch (e) {}
    return null;
  }

  const Site = {
    getName() {
      return storedName() || DEFAULT_NAME;
    },
    setName(val) {
      const name = normalizeName(val) || DEFAULT_NAME;
      try {
        localStorage.setItem("wh_site_name", name);
      } catch (e) {}
      // update globals and dispatch event
      window.SITE_NAME = name;
      window.SITE_SLUG = computeSlug(name);
      window.dispatchEvent(
        new CustomEvent("site:changed", {
          detail: { name, slug: window.SITE_SLUG },
        })
      );
      return name;
    },
    slug() {
      return computeSlug(this.getName());
    },
  };

  // expose
  window.Site = Site;
  window.SITE_NAME = Site.getName();
  window.SITE_SLUG = Site.slug();
})();
