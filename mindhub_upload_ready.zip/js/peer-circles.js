// Peer Circles - anonymous themed rooms
(function () {
  const roomBtns = document.querySelectorAll(".room-btn");
  const panel = document.getElementById("peerCirclePanel");
  const activeRoomEl = document.getElementById("activeRoom");
  const postsEl = document.getElementById("circlePosts");
  const input = document.getElementById("circleInput");
  const sendBtn = document.getElementById("circleSend");
  const leaveBtn = document.getElementById("circleLeave");
  const createBtn = document.getElementById("roomCreate");

  if (!panel) return;

  // Broadcast channel with fallback
  const BC_BASE = "wh_peer_circle_v1";
  let bc = null;
  try {
    bc = new BroadcastChannel(BC_BASE);
  } catch (e) {
    bc = null;
  }

  function channelFor(room) {
    return BC_BASE + ":" + room;
  }

  // simple storage of recent messages per room
  function storageKey(room) {
    return "wh_peer_circle_" + room;
  }

  function anonId() {
    // per-tab random id
    let id = sessionStorage.getItem("wh_peer_anon");
    if (!id) {
      id = "anon_" + Math.random().toString(36).slice(2, 9);
      sessionStorage.setItem("wh_peer_anon", id);
    }
    return id;
  }

  let currentRoom = null;

  function renderMsg(m) {
    const el = document.createElement("div");
    el.className = "p-2 rounded bg-white border";
    el.innerHTML = `<div class="text-xs text-gray-400">${
      m.id
    } · <span class="text-xs text-gray-400">${new Date(
      m.ts
    ).toLocaleTimeString()}</span></div><div class="mt-1 text-sm text-gray-800">${escapeHtml(
      m.text
    )}</div>`;
    postsEl.appendChild(el);
    postsEl.scrollTop = postsEl.scrollHeight;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      }[c];
    });
  }

  function loadRoom(room) {
    postsEl.innerHTML = "";
    const raw = localStorage.getItem(storageKey(room));
    if (raw) {
      try {
        const arr = JSON.parse(raw);
        (arr || []).forEach(renderMsg);
      } catch (e) {}
    }
  }

  function saveRoomMsg(room, msg) {
    try {
      const k = storageKey(room);
      const arr = JSON.parse(localStorage.getItem(k) || "[]");
      arr.push(msg);
      // keep last 200
      if (arr.length > 200) arr.shift();
      localStorage.setItem(k, JSON.stringify(arr));
    } catch (e) {}
  }

  function postToRoom(room, text) {
    const msg = { id: anonId(), ts: Date.now(), text: text };
    // broadcast
    if (bc) {
      bc.postMessage({ room: room, msg: msg });
    }
    // also write to localStorage (for fallback & persistence)
    saveRoomMsg(room, msg);
    // local render
    if (room === currentRoom) renderMsg(msg);
    // also trigger storage event for other tabs
    try {
      localStorage.setItem(storageKey(room) + "_notify", Date.now().toString());
    } catch (e) {}
  }

  // listen broadcast
  if (bc) {
    bc.onmessage = (ev) => {
      const { room, msg } = ev.data || {};
      if (!room || !msg) return;
      saveRoomMsg(room, msg);
      if (room === currentRoom) renderMsg(msg);
    };
  }

  // storage event fallback
  window.addEventListener("storage", (ev) => {
    if (!ev.key) return;
    if (ev.key.endsWith("_notify")) {
      const room = ev.key
        .replace(BC_BASE + ":", "")
        .replace("_notify", "")
        .replace("wh_peer_circle_", "");
      // load latest for currentRoom
      const raw = localStorage.getItem(storageKey(currentRoom));
      if (raw) {
        try {
          const arr = JSON.parse(raw);
          postsEl.innerHTML = "";
          (arr || []).forEach(renderMsg);
        } catch (e) {}
      }
    }
  });

  roomBtns.forEach((b) => {
    b.addEventListener("click", () => {
      const room = b.getAttribute("data-room");
      joinRoom(room);
    });
  });

  createBtn.addEventListener("click", () => {
    const name = prompt("Create room (id friendly, e.g. study-group):");
    if (!name) return;
    joinRoom(name);
  });

  function joinRoom(room) {
    currentRoom = room;
    panel.classList.remove("hidden");
    activeRoomEl.textContent = room;
    loadRoom(room);
  }

  sendBtn.addEventListener("click", () => {
    const t = input.value.trim();
    if (!t) return;
    postToRoom(currentRoom, t);
    input.value = "";
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      sendBtn.click();
    }
  });

  leaveBtn.addEventListener("click", () => {
    currentRoom = null;
    panel.classList.add("hidden");
    postsEl.innerHTML = "";
    activeRoomEl.textContent = "";
  });
})();
