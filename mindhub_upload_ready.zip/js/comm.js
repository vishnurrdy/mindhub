// Simple communication/pubsub module for Mind Hub
// Features:
// - Uses BroadcastChannel when available for cross-tab messaging
// - Falls back to localStorage "ping" events when BroadcastChannel unavailable
// - Persists messages to a history key if requested
// - Simple API: comm.on(event, handler), comm.off(event, handler), comm.emit(event, payload)

(function (global) {
  const HISTORY_KEY = "wh_comm_history";

  function now() {
    return Date.now();
  }

  class Comm {
    constructor(channelName) {
      // default channel uses site slug when available, fallback to literal
      const defaultChannel =
        window && window.SITE_SLUG
          ? window.SITE_SLUG + "_comm"
          : "mindhub_comm";

      this.channelName = channelName || defaultChannel;
      this.handlers = {}; // event -> [fn]
      this.bc = null;
      this._init();
    }

    _init() {
      if ("BroadcastChannel" in window) {
        try {
          this.bc = new BroadcastChannel(this.channelName);
          this.bc.onmessage = (e) => {
            this._receive(e.data);
          };
        } catch (e) {
          this.bc = null;
        }
      }
      // listen storage fallback
      window.addEventListener("storage", (ev) => {
        if (ev.key && ev.key.startsWith(this.channelName + ":")) {
          try {
            const data = JSON.parse(ev.newValue);
            this._receive(data);
          } catch (e) {}
        }
      });
    }

    _receive(msg) {
      if (!msg || !msg.event) return;
      const handlers = this.handlers[msg.event] || [];
      handlers.forEach((fn) => {
        try {
          fn(msg.payload, msg.meta);
        } catch (e) {
          console.error(e);
        }
      });
    }

    on(event, fn) {
      this.handlers[event] = this.handlers[event] || [];
      this.handlers[event].push(fn);
    }
    off(event, fn) {
      if (!this.handlers[event]) return;
      this.handlers[event] = this.handlers[event].filter((x) => x !== fn);
    }

    emit(event, payload = {}, options = { persist: false }) {
      const meta = { ts: now(), id: "m_" + now(), origin: location.hostname }; // origin not unique but okay for demo
      const msg = { event, payload, meta };
      // persist to history if asked
      if (options.persist) {
        this._persist(msg);
      }
      if (this.bc) {
        try {
          this.bc.postMessage(msg);
        } catch (e) {
          this._lsFallback(msg);
        }
      } else this._lsFallback(msg);
      // also deliver locally
      this._receive(msg);
    }

    _lsFallback(msg) {
      try {
        const key = this.channelName + ":" + msg.meta.id;
        localStorage.setItem(key, JSON.stringify(msg));
        // clean up quickly to avoid clutter
        setTimeout(() => {
          try {
            localStorage.removeItem(key);
          } catch (e) {}
        }, 1000);
      } catch (e) {
        console.error("ls fallback", e);
      }
    }

    _persist(msg) {
      try {
        const hist = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
        hist.unshift(msg);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(hist.slice(0, 500))); // cap to 500
      } catch (e) {
        console.error(e);
      }
    }

    history() {
      try {
        return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
      } catch (e) {
        return [];
      }
    }
  }

  global.WHComm = new Comm();
})(window);
