// Lightweight AI chat handler (offline-friendly)
// Stores conversations in localStorage under 'wh_ai_conversations'

(function () {
  const STORAGE_KEY = "wh_ai_conversations";
  const messagesEl = document.getElementById("chatMessages");
  const form = document.getElementById("chatForm");
  const input = document.getElementById("chatInput");
  const clearBtn = document.getElementById("clearConversations");
  const exportBtn = document.getElementById("exportConversations");
  // create remote toggle if not present
  let remoteToggle = document.getElementById("aiRemoteToggle");
  if (!remoteToggle) {
    remoteToggle = document.createElement("button");
    remoteToggle.id = "aiRemoteToggle";
    remoteToggle.className = "text-sm px-2 py-1 bg-gray-100 rounded";
    remoteToggle.textContent = "Remote: Off";
    // try to insert into header area if found
    const header =
      document.querySelector("strong + span") ||
      document.querySelector("div > strong");
    const container =
      document.querySelector(".ml-auto") ||
      document.querySelector(".flex.items-center");
    if (container) container.insertBefore(remoteToggle, container.firstChild);
  }

  function loadConversations() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }
  function saveConversations(arr) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
  }

  function renderMessages() {
    const arr = loadConversations();
    messagesEl.innerHTML = "";
    arr.forEach((m) => {
      const div = document.createElement("div");
      div.className = m.role === "user" ? "text-right" : "text-left";
      div.innerHTML = `<div class="inline-block max-w-[80%] p-2 rounded ${
        m.role === "user"
          ? "bg-teal-600 text-white"
          : "bg-gray-100 text-gray-900"
      }">${escapeHtml(m.text)}</div>`;
      messagesEl.appendChild(div);
    });
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function escapeHtml(s) {
    return (s + "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        }[c])
    );
  }

  function appendMessage(role, text) {
    const arr = loadConversations();
    arr.push({ role, text, ts: Date.now() });
    saveConversations(arr);
    renderMessages();
  }

  function simpleLocalReply(userText) {
    // Helpful offline responses. For open-ended questions, invite remote AI mode.
    const t = userText.toLowerCase();
    if (/\b(hi|hello|hey|good morning|good evening)\b/.test(t))
      return "Hi, I'm your Mind Hub wellness companion. 😊 What's on your mind today?";
    if (/suicid|self[- ]?harm|kill myself|end my life|hurt myself/.test(t))
      return "I'm really sorry you're feeling this way, and I'm glad you told me. If you may act on these thoughts or are in immediate danger, contact your local emergency number now and reach out to someone you trust who can stay with you. You deserve real-time support from a qualified person. This offline chat can't provide emergency help.";
    if (/panic|anxious|anxiety|stress|overwhelm|overwhelmed/.test(t))
      return "That sounds difficult. Try this quick grounding exercise: put both feet on the floor, relax your shoulders, and breathe out slowly for a little longer than you breathe in. Then name five things you can see and choose one small next step. Would you like help making a simple plan for what's stressing you?";
    if (/sleep|insomnia|can't sleep|cannot sleep/.test(t))
      return "A gentle sleep reset may help: dim bright screens, keep the room comfortable, and try a quiet wind-down routine at a similar time each night. If sleep problems persist or affect your daily life, consider speaking with a healthcare professional.";
    if (/sad|lonely|alone|depressed|down/.test(t))
      return "I'm sorry things feel heavy right now. You don't have to solve everything at once—could you choose one kind, manageable thing for yourself today, or message someone you trust? If these feelings persist or become intense, a mental-health professional can offer more support.";
    if (/goal|habit|motivat|procrastinat|focus|study|work/.test(t))
      return "Let's make this manageable: choose one task, shrink it to a 5-minute first step, and decide exactly when you'll begin. After five minutes, you can continue or take a short break. What's the one task you'd most like to make progress on?";
    if (/mind hub|this app|feature|how do i use/.test(t))
      return "Mind Hub is designed as a wellness companion. You can explore the pages available in your dashboard, such as goals, games, counselling, and peer support. I can give a more specific answer when remote AI is enabled, or if you tell me which page you're using.";
    return "I'm here to listen. Could you tell me a little more about what you need help with? For more detailed, context-aware answers, enable 'Allow remote AI' and choose Server proxy or a configured AI provider.";
  }

  async function sendToRemote(messages) {
    const r = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages }),
    });
    let j = {};
    try { j = await r.json(); } catch (_) {}
    if (!r.ok) {
      const detail = typeof j.error === "string" ? j.error :
        (j.error && (j.error.message || j.error.error?.message)) || `Server returned HTTP ${r.status}`;
      throw new Error(detail);
    }
    const reply = j.reply || j?.raw?.choices?.[0]?.message?.content;
    if (!reply) throw new Error("The AI provider returned an empty reply.");
    return reply;
  }

  // network status helper
  function isOnline() {
    return typeof navigator !== "undefined" ? navigator.onLine : true;
  }

  // reflect online/offline in the UI
  function updateNetworkIndicator() {
    const modeEl = document.getElementById("aiMode");
    if (!modeEl) return;
    if (!isOnline()) {
      modeEl.textContent = "Offline";
      if (remoteToggle) remoteToggle.disabled = true;
    } else {
      modeEl.textContent =
        remoteToggle && remoteToggle._on ? "Remote" : "Local";
      if (remoteToggle) remoteToggle.disabled = false;
    }
  }
  window.addEventListener("online", updateNetworkIndicator);
  window.addEventListener("offline", updateNetworkIndicator);
  updateNetworkIndicator();

  form.addEventListener("submit", async function (e) {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    appendMessage("user", text);
    input.value = "";
    // Simulate thinking
    appendMessage("assistant", "...");
    // Decide remote usage based on consent + selected mode
    const consent = localStorage.getItem("wh_ai_consent") === "1";
    const selectedMode =
      localStorage.getItem("wh_ai_mode") ||
      (modeSelect && modeSelect.value) ||
      "proxy";
    const canRemote = consent && isOnline();
    const useRemote = canRemote && selectedMode !== "local";
    if (!consent && selectedMode !== "local") {
      alert('Please check "Allow remote AI" to enable remote providers.');
    }
    if (useRemote) {
      const msgs = loadConversations()
        .filter((m) => m.text !== "...")
        .slice(-16)
        .map((m) => ({ role: m.role, text: m.text }));
      let remoteReply = null;
      let remoteErrorMessage = "";
      try {
        if (selectedMode === "proxy") {
          remoteReply = await sendToRemote(msgs);
        } else if (selectedMode === "openai") {
          const mapped = msgs.map((m) => ({
            role: m.role === "user" ? "user" : "assistant",
            content: m.text,
          }));
          remoteReply = await callOpenAI(mapped);
        } else if (selectedMode === "gemini") {
          const mapped = msgs.map((m) => ({
            role: m.role === "user" ? "user" : "assistant",
            content: m.text,
          }));
          remoteReply = await callGemini(mapped);
        }
      } catch (e) {
        console.warn("remote provider error", e);
        remoteErrorMessage = e && e.message ? e.message : "unknown error";
        remoteReply = null;
      }
      // remove '...'
      const arr = loadConversations();
      if (arr.length && arr[arr.length - 1].text === "...") arr.pop();
      saveConversations(arr);
      if (remoteReply) {
        appendMessage("assistant", remoteReply);
        return;
      }
      // Do not silently pretend the AI worked when the remote provider failed.
      const failedArr = loadConversations();
      if (failedArr.length && failedArr[failedArr.length - 1].text === "...") failedArr.pop();
      saveConversations(failedArr);
      appendMessage("assistant", `I couldn't connect to the AI service: ${remoteErrorMessage || "unknown error"}. Check that the server is running, OPENAI_API_KEY is set in the server .env file, and “Allow remote AI” plus “Server proxy” are selected.`);
      return;
    }
    setTimeout(() => {
      // remove the '...' placeholder
      const arr = loadConversations();
      if (arr.length && arr[arr.length - 1].text === "...") arr.pop();
      saveConversations(arr);
      const reply = simpleLocalReply(text);
      appendMessage("assistant", reply);
    }, 600);
  });

  clearBtn &&
    clearBtn.addEventListener("click", function () {
      localStorage.removeItem(STORAGE_KEY);
      renderMessages();
    });

  exportBtn &&
    exportBtn.addEventListener("click", function () {
      const data = JSON.stringify(loadConversations(), null, 2);
      const blob = new Blob([data], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "ai_conversations.json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });

  // remote toggle behaviour
  if (remoteToggle) {
    remoteToggle._on = false;
    remoteToggle.addEventListener("click", function () {
      remoteToggle._on = !remoteToggle._on;
      remoteToggle.textContent = remoteToggle._on
        ? "Remote: On"
        : "Remote: Off";
      const modeEl = document.getElementById("aiMode");
      if (modeEl) modeEl.textContent = remoteToggle._on ? "Remote" : "Local";
    });
  }

  // initial render
  renderMessages();

  // --- New: consent, mode and API key controls wiring ---
  const consentEl = document.getElementById("aiConsent");
  const modeSelect = document.getElementById("aiModeSelect");
  const setOpenAIKeyBtn = document.getElementById("setOpenAIKey");
  const setGeminiKeyBtn = document.getElementById("setGeminiKey");

  // helper: direct OpenAI call (browser-side)
  async function callOpenAI(messages) {
    const key = localStorage.getItem("wh_openai_key");
    if (!key) throw new Error("No OpenAI key");
    const body = { model: "gpt-3.5-turbo", messages };
    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + key,
      },
      body: JSON.stringify(body),
    });
    if (!resp.ok) throw new Error("OpenAI error");
    const j = await resp.json();
    return j.choices?.[0]?.message?.content || null;
  }

  // helper: direct Gemini call (browser-side minimal)
  async function callGemini(messages) {
    const key = localStorage.getItem("wh_gemini_key");
    if (!key) throw new Error("No Gemini key");
    const last = messages[messages.length - 1];
    const userText = (last && (last.content || last.text || last)) || "";
    const url =
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.0:generateText?key=" +
      encodeURIComponent(key);
    const body = { prompt: userText, temperature: 0.7 };
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!resp.ok) throw new Error("Gemini error");
    const j = await resp.json();
    return j?.candidates?.[0]?.content || j?.output?.[0]?.content || null;
  }

  // Load persisted preferences into UI
  try {
    const consentSaved = localStorage.getItem("wh_ai_consent") === "1";
    if (consentEl) consentEl.checked = consentSaved;
    const modeSaved = localStorage.getItem("wh_ai_mode") || "proxy";
    if (modeSelect) modeSelect.value = modeSaved;
    const modeEl = document.getElementById("aiMode");
    if (modeEl)
      modeEl.textContent =
        modeSaved === "local"
          ? "Local"
          : modeSaved === "proxy"
          ? "Proxy"
          : modeSaved === "openai"
          ? "OpenAI"
          : "Gemini";
  } catch (e) {}

  if (consentEl)
    consentEl.addEventListener("change", () => {
      localStorage.setItem("wh_ai_consent", consentEl.checked ? "1" : "0");
    });
  if (modeSelect)
    modeSelect.addEventListener("change", () => {
      localStorage.setItem("wh_ai_mode", modeSelect.value);
      const modeEl = document.getElementById("aiMode");
      if (modeEl)
        modeEl.textContent =
          modeSelect.value === "local"
            ? "Local"
            : modeSelect.value === "proxy"
            ? "Proxy"
            : modeSelect.value === "openai"
            ? "OpenAI"
            : "Gemini";
    });

  if (setOpenAIKeyBtn)
    setOpenAIKeyBtn.addEventListener("click", () => {
      const existing = localStorage.getItem("wh_openai_key") || "";
      const k = prompt(
        "Paste your OpenAI API key (stored locally in your browser only):",
        existing
      );
      if (k === null) return;
      if (k.trim() === "") {
        localStorage.removeItem("wh_openai_key");
        alert("OpenAI key removed.");
        return;
      }
      localStorage.setItem("wh_openai_key", k.trim());
      alert("OpenAI key saved locally.");
    });

  if (setGeminiKeyBtn)
    setGeminiKeyBtn.addEventListener("click", () => {
      const existing = localStorage.getItem("wh_gemini_key") || "";
      const k = prompt(
        "Paste your Gemini API key (stored locally in your browser only):",
        existing
      );
      if (k === null) return;
      if (k.trim() === "") {
        localStorage.removeItem("wh_gemini_key");
        alert("Gemini key removed.");
        return;
      }
      localStorage.setItem("wh_gemini_key", k.trim());
      alert("Gemini key saved locally.");
    });
})();
