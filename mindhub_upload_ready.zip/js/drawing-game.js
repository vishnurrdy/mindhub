// Simple Drawing Playground
(function () {
  const canvas = document.getElementById("drawCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const DPR = window.devicePixelRatio || 1;

  function resizeCanvas() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    canvas.width = Math.round(w * DPR);
    canvas.height = Math.round(h * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    redrawFromBuffer();
  }

  let drawing = false;
  let last = { x: 0, y: 0 };
  const state = {
    color: "#111827",
    size: 6,
  };

  // keep a simple buffer for persistent redraws
  let strokes = []; // each stroke: {color,size,points: [{x,y},...], tool: 'pen'|'eraser'}
  let undoStack = [];
  let redoStack = [];
  let currentTool = "pen"; // pen, fill, eraser

  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    // convert to canvas CSS coords, then scale to drawing coords
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    return { x: x, y: y };
  }

  function beginStroke(p) {
    drawing = true;
    last = p;
    strokes.push({
      color: state.color,
      size: state.size,
      points: [p],
      tool: currentTool,
    });
  }
  function extendStroke(p) {
    if (!drawing) return;
    const s = strokes[strokes.length - 1];
    s.points.push(p);
    drawLine(last, p, s.color, s.size);
    last = p;
  }
  function endStroke() {
    drawing = false;
    saveIfNeeded();
    // save snapshot for undo
    pushUndo();
  }

  function pushUndo() {
    try {
      undoStack.push(JSON.stringify(strokes));
      // cap undo history
      if (undoStack.length > 50) undoStack.shift();
      redoStack.length = 0;
    } catch (e) {}
  }

  function doUndo() {
    if (!undoStack.length) return;
    try {
      redoStack.push(JSON.stringify(strokes));
      const raw = undoStack.pop();
      strokes = JSON.parse(raw) || [];
      redrawFromBuffer();
      saveIfNeeded();
    } catch (e) {}
  }

  function doRedo() {
    if (!redoStack.length) return;
    try {
      undoStack.push(JSON.stringify(strokes));
      const raw = redoStack.pop();
      strokes = JSON.parse(raw) || [];
      redrawFromBuffer();
      saveIfNeeded();
    } catch (e) {}
  }

  function drawLine(p1, p2, color, size) {
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = color;
    ctx.lineWidth = size;
    ctx.beginPath();
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.stroke();
    ctx.restore();
  }

  function redrawFromBuffer() {
    ctx.clearRect(0, 0, canvas.width / DPR, canvas.height / DPR);
    for (const s of strokes) {
      if (s.tool === "image" && s.imgDataUrl) {
        const img = new Image();
        img.src = s.imgDataUrl;
        // draw synchronously when loaded
        img.onload = () => {
          ctx.drawImage(img, 0, 0, canvas.width / DPR, canvas.height / DPR);
        };
        continue;
      }
      if (!s.points || s.points.length === 0) continue;
      if (s.tool === "eraser") {
        ctx.save();
        ctx.globalCompositeOperation = "destination-out";
        for (let i = 1; i < s.points.length; i++)
          drawLine(s.points[i - 1], s.points[i], "rgba(0,0,0,1)", s.size);
        ctx.restore();
      } else {
        for (let i = 1; i < s.points.length; i++)
          drawLine(s.points[i - 1], s.points[i], s.color, s.size);
      }
    }
  }

  // controls
  document.getElementById("brushSize").addEventListener("input", (e) => {
    const v = parseInt(e.target.value, 10);
    state.size = v;
    const lbl = document.getElementById("brushSizeLabel");
    if (lbl) lbl.textContent = v + " px";
  });

  document.getElementById("colorPalette").addEventListener("click", (e) => {
    const btn = e.target.closest(".color-swatch");
    if (!btn) return;
    const c = btn.getAttribute("data-color");
    if (c) state.color = c;
    // highlight selection
    document
      .querySelectorAll("#colorPalette .color-swatch")
      .forEach((b) =>
        b.classList.remove("ring-2", "ring-black", "ring-opacity-30")
      );
    btn.classList.add("ring-2", "ring-black", "ring-opacity-30");
  });

  // color picker input
  const colorInput = document.getElementById("colorPicker");
  if (colorInput)
    colorInput.addEventListener("input", (e) => {
      state.color = e.target.value;
    });

  // tool buttons
  document.getElementById("toolPen").addEventListener("click", () => {
    currentTool = "pen";
    updateToolUI();
  });
  document.getElementById("toolFill").addEventListener("click", () => {
    currentTool = "fill";
    updateToolUI();
  });
  document.getElementById("toolEraser").addEventListener("click", () => {
    currentTool = "eraser";
    updateToolUI();
  });

  function updateToolUI() {
    document
      .querySelectorAll(".tool-btn")
      .forEach((b) => b.classList.remove("bg-white", "ring-2"));
    const id =
      currentTool === "pen"
        ? "toolPen"
        : currentTool === "fill"
        ? "toolFill"
        : "toolEraser";
    const el = document.getElementById(id);
    if (el) el.classList.add("bg-white", "ring-2");
  }

  document.getElementById("clearDraw").addEventListener("click", () => {
    strokes.length = 0;
    ctx.clearRect(0, 0, canvas.width / DPR, canvas.height / DPR);
    localStorage.removeItem("wh_drawing_sketch");
    pushUndo();
  });

  document.getElementById("saveDraw").addEventListener("click", () => {
    const dataUrl = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = "sketch.png";
    document.body.appendChild(a);
    a.click();
    a.remove();
  });

  function saveIfNeeded() {
    const persist = document.getElementById("persistDraw");
    if (persist && persist.checked) {
      try {
        localStorage.setItem("wh_drawing_sketch", JSON.stringify(strokes));
      } catch (e) {}
    }
  }

  function loadIfExists() {
    try {
      const raw = localStorage.getItem("wh_drawing_sketch");
      if (!raw) return;
      const data = JSON.parse(raw);
      if (Array.isArray(data)) {
        strokes = data;
        redrawFromBuffer();
      }
    } catch (e) {}
  }

  // pointer events
  canvas.addEventListener("pointerdown", (ev) => {
    canvas.setPointerCapture(ev.pointerId);
    const p = getPos(ev);
    if (currentTool === "fill") {
      // flood fill at p; convert CSS coords to pixel coords
      const rect = canvas.getBoundingClientRect();
      const cw = canvas.width / DPR;
      const ch = canvas.height / DPR;
      const px = Math.round((p.x / rect.width) * cw);
      const py = Math.round((p.y / rect.height) * ch);
      floodFill(px, py, state.color);
      pushUndo();
      saveIfNeeded();
    } else if (currentTool === "eraser") {
      // eraser behaves as a large white pen
      // begin an eraser stroke
      beginStroke(p);
    } else {
      beginStroke(p);
    }
  });
  canvas.addEventListener("pointermove", (ev) => {
    const p = getPos(ev);
    extendStroke(p);
  });
  window.addEventListener("pointerup", (ev) => {
    try {
      canvas.releasePointerCapture(ev.pointerId);
    } catch (e) {}
    endStroke();
  });

  // undo/redo handlers
  document.getElementById("undoBtn").addEventListener("click", doUndo);
  document.getElementById("redoBtn").addEventListener("click", doRedo);

  // resize handling
  window.addEventListener("resize", () => {
    resizeCanvas();
  });

  // initialize
  resizeCanvas();
  loadIfExists();
  // set first palette item highlighted
  const first = document.querySelector("#colorPalette .color-swatch");
  if (first) first.classList.add("ring-2", "ring-black", "ring-opacity-30");
  updateToolUI();

  // template loading
  function loadTemplate(name) {
    // simple hard-coded SVG paths from the inline templates in games.html
    const tplMap = {
      flower: `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 80'><path d='M60 42 C68 30, 88 28, 92 20 C96 12, 80 6, 68 12 C56 18, 54 6, 44 8 C34 10, 28 24, 36 34 C44 44, 36 60, 50 64 C64 68, 76 58, 80 46 C84 34, 72 34, 60 42 Z' stroke='#222' stroke-width='2' fill='none'/><path d='M60 42 L60 72' stroke='#222' stroke-width='2' fill='none'/><circle cx='60' cy='36' r='6' stroke='#222' stroke-width='2' fill='none'/></svg>`,
      cat: `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 80'><path d='M20 44 C20 30, 34 20, 50 24 C66 28, 76 18, 100 28 C90 16, 112 8, 108 28 C104 48, 84 54, 82 64 C80 74, 60 78, 50 70 C40 62, 24 60, 20 44 Z' stroke='#222' stroke-width='2' fill='none'/><circle cx='46' cy='42' r='4' stroke='#222' stroke-width='1.5' fill='none'/><circle cx='82' cy='46' r='4' stroke='#222' stroke-width='1.5' fill='none'/></svg>`,
      landscape: `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 80'><rect x='6' y='28' width='108' height='44' rx='6' stroke='#222' stroke-width='2' fill='none'/><path d='M14 60 C30 42, 46 68, 64 50 C80 34, 100 66, 106 54' stroke='#222' stroke-width='2' fill='none'/><circle cx='28' cy='38' r='6' stroke='#222' stroke-width='2' fill='none'/></svg>`,
    };
    const svg = tplMap[name];
    if (!svg) return;
    // draw SVG onto canvas as outline using an Image
    const img = new Image();
    const svgBlob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(svgBlob);
    img.onload = () => {
      // center and scale to canvas
      const cw = canvas.width / DPR;
      const ch = canvas.height / DPR;
      // draw at full canvas size, keeping aspect
      ctx.clearRect(0, 0, cw, ch);
      ctx.drawImage(img, 0, 0, cw, ch);
      // capture as a base stroke to keep outline
      strokes.push({
        color: "#222",
        size: 2,
        points: [],
        tool: "image",
        imgDataUrl: canvas.toDataURL(),
      });
      pushUndo();
      saveIfNeeded();
      URL.revokeObjectURL(url);
    };
    img.src = url;
  }

  document.querySelectorAll(".template-btn").forEach((b) => {
    b.addEventListener("click", () => {
      const t = b.getAttribute("data-template");
      loadTemplate(t);
    });
  });
  document.getElementById("clearTemplate").addEventListener("click", () => {
    // remove image-like strokes
    strokes = strokes.filter((s) => s.tool !== "image");
    redrawFromBuffer();
    pushUndo();
    saveIfNeeded();
  });

  // flood fill algorithm (simple, iterative)
  function floodFill(startX, startY, fillColor) {
    try {
      const cw = canvas.width / DPR;
      const ch = canvas.height / DPR;
      const imgData = ctx.getImageData(0, 0, cw, ch);
      const data = imgData.data;
      const idx = (y, x) => (y * cw + x) * 4;
      const targetIdx = idx(startY, startX);
      const targetR = data[targetIdx];
      const targetG = data[targetIdx + 1];
      const targetB = data[targetIdx + 2];
      const targetA = data[targetIdx + 3];
      // if pixel is fully transparent, treat transparency as fillable area
      const hexToRgba = (hex) => {
        const h = hex.replace("#", "");
        const bigint = parseInt(h, 16);
        if (h.length === 6)
          return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255, 255];
        return [0, 0, 0, 255];
      };
      const fillCol = hexToRgba(fillColor);
      // if target color same as fill, bail
      if (
        targetR === fillCol[0] &&
        targetG === fillCol[1] &&
        targetB === fillCol[2] &&
        targetA === fillCol[3]
      )
        return;
      const stack = [[startX, startY]];
      while (stack.length) {
        const [x, y] = stack.pop();
        if (x < 0 || x >= cw || y < 0 || y >= ch) continue;
        const i = idx(y, x);
        // compare pixel equality
        if (
          data[i] === targetR &&
          data[i + 1] === targetG &&
          data[i + 2] === targetB &&
          data[i + 3] === targetA
        ) {
          data[i] = fillCol[0];
          data[i + 1] = fillCol[1];
          data[i + 2] = fillCol[2];
          data[i + 3] = fillCol[3];
          stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
        }
      }
      ctx.putImageData(imgData, 0, 0);
    } catch (e) {
      console.warn("fill failed", e);
    }
  }
})();
