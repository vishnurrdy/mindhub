// Fruit Smash - simple casual game
(function () {
  const area = document.getElementById("fruitArea");
  if (!area) return;
  let timer = null;
  let spawnTimer = null;
  let timeLeft = 30;
  let score = 0;
  const fruits = ["🍎", "🍊", "🍋", "🍇", "🍓", "🥝"];

  function rand(max) {
    return Math.floor(Math.random() * max);
  }

  function spawnFruit() {
    const f = document.createElement("div");
    f.className = "fruit";
    f.style.position = "absolute";
    const size = 36 + Math.random() * 40;
    f.style.width = size + "px";
    f.style.height = size + "px";
    const x = Math.random() * (area.clientWidth - size);
    const y = Math.random() * (area.clientHeight - size);
    f.style.left = x + "px";
    f.style.top = y + "px";
    f.style.display = "flex";
    f.style.alignItems = "center";
    f.style.justifyContent = "center";
    f.style.fontSize = Math.round(size * 0.6) + "px";
    f.style.cursor = "pointer";
    f.textContent = fruits[rand(fruits.length)];
    f.style.userSelect = "none";
    f.addEventListener("click", () => {
      smashFruit(f);
    });
    area.appendChild(f);
    // auto remove after some time
    setTimeout(() => {
      if (f.parentNode) f.remove();
    }, 4000 + Math.random() * 4000);
  }

  function smashFruit(el) {
    if (!el) return;
    // pop animation
    el.style.transform = "scale(0.2) rotate(-30deg)";
    el.style.opacity = "0";
    setTimeout(() => {
      if (el.parentNode) el.remove();
    }, 300);
    score += 10;
    document.getElementById("fruitScore").textContent = score;
    // small burst
    const burst = document.createElement("div");
    burst.textContent = "💥";
    burst.style.position = "absolute";
    burst.style.left = el.style.left;
    burst.style.top = el.style.top;
    burst.style.fontSize = "22px";
    area.appendChild(burst);
    setTimeout(() => {
      burst.remove();
    }, 500);
  }

  function tick() {
    timeLeft -= 1;
    document.getElementById("fruitTimer").textContent = timeLeft;
    if (timeLeft <= 0) {
      stopGame();
    }
  }

  function startGame() {
    stopGame();
    timeLeft = 30;
    score = 0;
    document.getElementById("fruitTimer").textContent = timeLeft;
    document.getElementById("fruitScore").textContent = score;
    timer = setInterval(tick, 1000);
    spawnTimer = setInterval(spawnFruit, 600);
  }
  function stopGame() {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
    if (spawnTimer) {
      clearInterval(spawnTimer);
      spawnTimer = null;
    }
  }

  document.getElementById("startFruit").addEventListener("click", startGame);
  document.getElementById("stopFruit").addEventListener("click", stopGame);
})();
