(function () {
  // Quick action buttons
  const quickGoalBtn = document.getElementById("quickGoalBtn");
  const quickPeerBtn = document.getElementById("quickPeerBtn");
  const quickAI = document.getElementById("quickAI");
  const microBar = document.getElementById("microGoalBar");
  const microPct = document.getElementById("microGoalPct");
  const microWrap = document.getElementById("microGoalProgress");

  function open(path) {
    window.location.href = path;
  }
  if (quickGoalBtn)
    quickGoalBtn.addEventListener("click", () => open("micro-goals.html"));
  if (quickPeerBtn)
    quickPeerBtn.addEventListener("click", () => open("peer-support.html"));
  if (quickAI) quickAI.addEventListener("click", () => open("ai-chat.html"));

  function computeProgress() {
    try {
      const raw = localStorage.getItem("wh_micro_goals_v1");
      if (!raw) {
        if (microWrap) microWrap.classList.add("hidden");
        return;
      }
      const goals = JSON.parse(raw || "[]");
      if (!goals || !goals.length) {
        if (microWrap) microWrap.classList.add("hidden");
        return;
      }
      let total = 0,
        done = 0;
      goals.forEach((g) => {
        const subs = g.subtasks || [];
        if (subs.length === 0) {
          total += 1;
          if (g.done) done += 1;
        } else {
          total += subs.length;
          done += subs.filter((s) => s.done).length;
        }
      });
      const pct = total === 0 ? 0 : Math.round((done / total) * 100);
      if (microBar) microBar.style.width = pct + "%";
      if (microPct) microPct.textContent = pct + "%";
      if (microWrap) microWrap.classList.remove("hidden");
    } catch (e) {
      console.warn("progress error", e);
    }
  }

  computeProgress();
  // recompute when storage changes
  window.addEventListener("storage", computeProgress);
})();
