(function (window) {
  // Very small client-side i18n helper (demo) - reads localStorage.wh_lang
  const translations = {
    en: {
      back_dashboard: "← Back to Dashboard",
      settings_title: "Settings",
      peer_support: "Peer Support",
      post_placeholder: "Share something with the community...",
      post: "Post",
      reload: "Reload",
      export: "Export",
      contacts: "Contacts",
      add: "Add",
      add_sample_doctor: "Add sample doctor",
      send_pm: "Send",
      signin: "Sign In",
      welcome_back: "Welcome Back",
      sign_up: "Sign up",
      create_account: "Create account",
      back_to_signin: "Back to sign in",
      dashboard: "Dashboard",
      profile: "Profile",
      media: "Media",
      media_library: "Media Library",
      counselling: "Counselling",
      save_settings: "Save Settings",
      casual_settings: "Casual Settings",
      accent: "Accent color",
      font_size: "Font size",
      privacy_mode: "Privacy mode",
      autoplay_media: "Autoplay media",
      daily_reminder: "Daily reminder",
      compact_layout: "Compact layout",
      save_profile: "Save profile",
      reset: "Reset",
      go_to_login: "Go to login now",
      site_name: "Mind Hub",
      signing_out: "Signing you out…",
    },
    hi: {
      back_dashboard: "← डैशबोर्ड पर वापस",
      settings_title: "सेटिंग्स",
      peer_support: "पीयर समर्थन",
      post_placeholder: "समुदाय के साथ कुछ साझा करें...",
      post: "पोस्ट करें",
      reload: "रीलोड",
      export: "निर्यात",
      contacts: "संपर्क",
      add: "जोड़ें",
      add_sample_doctor: "नमूना डॉक्टर जोड़ें",
      send_pm: "भेजें",
      signin: "साइन इन",
      welcome_back: "वापसी पर स्वागत है",
      sign_up: "साइन अप",
      create_account: "खाता बनाएं",
      back_to_signin: "साइन इन पर वापस",
      dashboard: "डैशबोर्ड",
      profile: "प्रोफ़ाइल",
      media: "मीडिया",
      media_library: "मीडिया लाइब्रेरी",
      counselling: "काउंसलिंग",
      save_settings: "सेटिंग्स सहेजें",
      casual_settings: "कज़ुअल सेटिंग्स",
      accent: "अभिनय रंग",
      font_size: "फ़ॉन्ट आकार",
      privacy_mode: "गोपनीयता मोड",
      autoplay_media: "ऑटोप्ले मीडिया",
      daily_reminder: "दैनिक अनुस्मारक",
      compact_layout: "कम्पैक्ट लेआउट",
      save_profile: "प्रोफ़ाइल सहेजें",
      reset: "रीसेट",
      go_to_login: "अब लॉगिन पर जाएँ",
      site_name: "Mind Hub",
      signing_out: "साइन आउट कर रहे हैं…",
    },
    te: {
      back_dashboard: "← డాష్‌బోర్డ్‌కు వెనక్కి",
      settings_title: "సెట్టింగ్స్",
      peer_support: "పియర్ సపోర్ట్",
      post_placeholder: "సమాజంతో ఏదైనా పంచుకోండి...",
      post: "పోస్ట్ చేయండి",
      reload: "రీఛార్ట్",
      export: "ఎగుమతి",
      contacts: "సంపర్కాలు",
      add: "జోడించండి",
      add_sample_doctor: "నమూనా డాక్టర్ జోడించండి",
      send_pm: "పంపు",
      signin: "సైన్ ఇన్",
      welcome_back: "మళ్ళీ స్వాగతం",
      sign_up: "సైన్ అప్",
      create_account: "ఖాతాను సృష్టించండి",
      back_to_signin: "సైన్ ఇన్‌కు తిరిగి",
      dashboard: "డెష్‌బోర్డ్",
      profile: "ప్రొఫైల్",
      media: "మీడియా",
      media_library: "మీడియా లైబ్రరీ",
      counselling: "కౌన్సెలింగ్",
      save_settings: "సెట్టింగ్స్ సేవ్ చేయండి",
      casual_settings: "క్యాజువల్ సెట్టింగ్స్",
      accent: "ఆకమెంట్ రంగు",
      font_size: "ఫాంట్ పరిమాణం",
      privacy_mode: "ప్రైవసీ మోడ్",
      autoplay_media: "ఆటోప్లే మీడియా",
      daily_reminder: "దైనందిన రిమైండర్",
      compact_layout: "కంపాక్ట్ లేఅవుట్",
      save_profile: "ప్రొఫైల్ సేవ్ చేయండి",
      reset: "రీసెట్",
      go_to_login: "ఇప్పుడే లాగిన్‌కు వెళ్ళండి",
      site_name: "Mind Hub",
      signing_out: "సైన్ అవుట్ అవుతున్నాం…",
    },
  };

  function t(key) {
    const lang = localStorage.getItem("wh_lang") || "en";
    return (
      (translations[lang] && translations[lang][key]) ||
      translations["en"][key] ||
      key
    );
  }

  function applyOnce(root = document) {
    // text content
    root.querySelectorAll("[data-i18n]").forEach((el) => {
      const k = el.getAttribute("data-i18n");
      const text = t(k);
      if (text) el.textContent = text;
    });
    // placeholders
    root.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      const k = el.getAttribute("data-i18n-placeholder");
      const text = t(k);
      if (text) el.setAttribute("placeholder", text);
    });
  }

  // run on DOMContentLoaded
  document.addEventListener("DOMContentLoaded", () => {
    applyOnce(document);
  });

  // expose for manual reapply
  window.__MH_i18n = { t, apply: applyOnce };
})(window);
